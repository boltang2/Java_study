package ex4_work;

public class Main {
	public static void main(String[] args) {
		String[] word = { "aaa", "bbb", "ccc", "ddd", "eee" };
		Words w = new Words(word);

		w.start();
		w.game();
	}
}
